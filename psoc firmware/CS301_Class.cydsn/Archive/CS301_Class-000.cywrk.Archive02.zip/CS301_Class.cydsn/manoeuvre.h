/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */
#ifndef MANOEUVRE
#define MANOEUVRE
    
#include <project.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

void edge_front_left_manoeuvre();
void edge_front_right_manoeuvre();
void edge_mid_left_manoeuvre();
void edge_mid_right_manoeuvre();
void edge_left_wing_manoeuvre();
void edge_right_wing_manoeuvre();
#endif