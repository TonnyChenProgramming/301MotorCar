/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include "SENSORS_READ.h"

// Returns error: -1 = drift left, 0 = centered, +1 = drift right
int8_t GetLineError(void)
{
    int8_t error = 0;
    if (!Output_1_Read()) error = -1;  // mid_left active
    if (!Output_3_Read()) error = +1;  // mid_right active
    return error;
}


uint8 sensorValues;
MovementState previous_movement;
MovementState current_movement;
struct MyStructure {   // Structure declaration
    uint8_t output1;
    uint8_t output2;
    uint8_t output3;
    uint8_t output4;
    uint8_t output5;
    uint8_t output6;
};
struct MyStructure this_struct = {0,0,0,0,0,0};
// Read 6 output pins are turn into a pattern
uint8 ReadSensors(void) {
    uint8 sensorValues = 0;
    
   sensorValues |= Output_5_Read() << 0; // Right
   sensorValues |= Output_6_Read() << 1;
   sensorValues |= Output_1_Read() << 2;
   sensorValues |= Output_3_Read() << 3;
   sensorValues |= Output_2_Read() << 4;
   sensorValues |= Output_4_Read() << 5; // Left
   
    /* LEDs on when sensor is on the line (active-low) */
    LED3_Write(Output_1_Read() ? 0 : 1);
    LED5_Write(Output_2_Read() ? 0 : 1);
    LED4_Write(Output_3_Read() ? 0 : 1);
    LED6_Write(Output_4_Read() ? 0 : 1);
    LED1_Write(Output_5_Read() ? 0 : 1);
    LED2_Write(Output_6_Read() ? 0 : 1);
    
   return sensorValues;
}


MovementState GetMovement(void)
{
    uint8 sensors = ReadSensors();

    // Wing sensors first → trigger hard turns
    if (!Output_4_Read()) {   // left wing active
        previous_movement = LEFT_TURN;
        return LEFT_TURN;
    }
    else if (!Output_5_Read()) {  // right wing active
        previous_movement = RIGHT_TURN;
        return RIGHT_TURN;
    }

    // If we were turning, but middle sensors are not back yet → WAIT
    if ((previous_movement == LEFT_TURN || previous_movement == RIGHT_TURN)) 
    {
        // Check middle sensors
        if (!Output_1_Read() || !Output_3_Read()) {
            return WAIT;  // stay in WAIT until line reacquired
        } else {
            previous_movement = STRAIGHT; // line back under middle sensors
        }
    }

    // Compute line error for PID
    int8_t error = GetLineError();

    if (error == 0) {
        previous_movement = STRAIGHT;
        return STRAIGHT;  // centered
    } else {
        previous_movement = STRAIGHT;
        return STRAIGHT;  // off-center → PID corrects
    }

    // Fallback
    previous_movement = STOP;
    return STOP;
}
